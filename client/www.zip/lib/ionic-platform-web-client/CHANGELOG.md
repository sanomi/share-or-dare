## 0.1.1

* (push) fixed notification handling for dev_push when using angular integrations
* (push) getPayload() now returns the correct payload
* (analytics) fixed incorrect log method references

## 0.1.0

* web client introduction

